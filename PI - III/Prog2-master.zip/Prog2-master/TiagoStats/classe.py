class Pessoa():
    def __init__(self, nome, idade, telefone):
        self.nome = nome
        self.idade = idade
        self.telefone = telefone

if __name__ == "__main__":
    joao = Pessoa("Maria", "Rua 9", "3232-1414")
    print(joao.nome)