from flask import Flask , render_template, request
from classe import Pessoa

app = Flask(__name__)
lista = []

@app.route("/")
def inicio():
    return render_template ("Inicio.html")

@app.route("/listarpessoa")
def listarPessoas():
    return render_template ("ListarPessoa.html", geral=lista)


@app.route("/alterarpessoa")
def alterarPessoa():
    return render_template ("AlterarPessoa.html")

@app.route("/exibirmensagem")
def exibirMensagem():
    return render_template ("ExibirMensagem.html")

@app.route("/cadastrarpessoa")
def cadastrarPessoa():
    # capturar os valores do formulário
    nome = request.args.get("nome")
    idade = request.args.get("idade")
    telefone = request.args.get("telefone")
    
    # criar uma instância da classe Pessoa ("criar uma pessoa")
    novaPessoa = Pessoa(nome, idade, telefone)

    # adicionar essa pessoa na lista
    lista.append (novaPessoa)

    # retornar o fluxo de execução para a tela de listagem
    return listarPessoas()
            
@app.route("/form_cadastrar_pessoa")
def form_cadastrar():
    return render_template ("CadastrarPessoa.html")

app.run(debug=True, host="0.0.0.0")
