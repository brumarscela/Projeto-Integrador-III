"""Teste das funções do Github.com"""
a = int(input("Insira um texto: "))
print (a)